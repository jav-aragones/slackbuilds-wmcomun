#pragma once

#include "application.h"

void path_find_programs(struct application_list *applications);
