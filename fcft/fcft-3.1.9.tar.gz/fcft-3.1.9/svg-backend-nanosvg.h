#pragma once

#include <ft2build.h>
#include FT_OTSVG_H

extern SVG_RendererHooks nanosvg_hooks;
