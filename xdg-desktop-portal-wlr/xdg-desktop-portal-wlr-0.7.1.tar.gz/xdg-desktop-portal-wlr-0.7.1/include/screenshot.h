#ifndef SCREENSHOT_H
#define SCREENSHOT_H


struct xdpw_ppm_pixel {
	int max_color_value;
	unsigned char red, green, blue;
};

#endif