#ifndef MAKO_STRING_H
#define MAKO_STRING_H

char *mako_asprintf(const char *fmt, ...);

#endif
